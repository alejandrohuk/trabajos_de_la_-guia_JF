﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CentralTelefonica;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CentralitaInstanciada()
        {
            Centralita c1 = new Centralita();
            Assert.IsNotNull(c1.Llamadas);
        }

        [TestMethod]
        public void LlamadaLocalExistente()
        {
            Centralita c1 = new Centralita();
            Local l1 = new Local(25f, "154", "4552-8008", 25f);
            Local l2 = new Local(25f, "154", "4552-8008", 25f);
            try
            {
                c1 += l1;
                c1 += l2;
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is CentralitaException);
            }
        }

        [TestMethod]
        public void LlamadaProvincialExistente()
        {
            Centralita c1 = new Centralita();
            Provincial p1 = new Provincial("15-3054-8778", Provincial.Franja.Franja_1, 12f, "4686-4444");
            Provincial p2 = new Provincial("15-3054-8778", Provincial.Franja.Franja_1, 12f, "4686-4444");
            try
            {
                c1 += p1;
                c1 += p2;
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is CentralitaException);
            }
        }


        [TestMethod]
        public void LlamadaMixtaExistente()
        {
            Provincial p1 = new Provincial("15-3054-8778", Provincial.Franja.Franja_1, 12f, "4686-4444");
            Provincial p2 = new Provincial("15-3054-8778", Provincial.Franja.Franja_1, 12f, "4686-4444");
            Local l1 = new Local(12f, "4686-4444", "15-3054-8778", 25f);
            Local l2 = new Local(12f, "4686-4444", "15-3054-8778", 25f);

            if (p1 == l1 || p2 == l2 || p2 == l1 || p1 == l2) Assert.Fail("Error en la comparacion");
            Assert.IsTrue(p1 == p2 && l1 == l2);
        }
    }
}
