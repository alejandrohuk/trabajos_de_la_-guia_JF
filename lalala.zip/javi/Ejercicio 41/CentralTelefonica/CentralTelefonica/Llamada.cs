﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralTelefonica
{
    public abstract class Llamada
    {

        #region Campos

        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;

        #endregion

        #region Constructores

        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            _duracion = duracion;
            _nroDestino = nroDestino;
            _nroOrigen = nroOrigen;
        }

        #endregion

        #region Propiedades
        
        public abstract float CostoLlamada { get; }

        public float Duracion
        {
            get 
            {
                return _duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return _nroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return _nroOrigen;
            }
        }

        #endregion

        #region Métodos

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            int output;
            if (llamada1._duracion > llamada2._duracion) output = 1;
            else if (llamada1._duracion < llamada2._duracion) output = -1;
            else output = 0;

            return output;
        }

        protected virtual string Mostrar()
        {
            StringBuilder sBuilder = new StringBuilder();
            sBuilder.AppendFormat("Duracion: {0:F2}\n", _duracion);
            sBuilder.AppendLine("Nro de origen: " + _nroOrigen);
            sBuilder.AppendLine("Nro de destino: " + _nroDestino);
            return sBuilder.ToString();
        }

        #endregion

        #region Sobrecarga de operadores

        public static bool operator ==(Llamada l1, Llamada l2)
        {
            bool output = false;
            if (l1.Equals(l2))
            {
                if ((l1.NroDestino == l2.NroDestino) && (l1.NroOrigen == l2.NroOrigen)) output = true;
            }
            
            return output;
        }

        public static bool operator !=(Llamada l1, Llamada l2)
        {
            bool output = true;
            if (l1.Equals(l2))
            {
                if ((l1.NroDestino == l2.NroDestino) && (l1.NroOrigen == l2.NroOrigen)) output = false;
            }
            return output;
        }

        #endregion

        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
    }
}
