﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralTelefonica
{
    public class Centralita
    {
        #region Campos

        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        #endregion

        #region Constructores

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa)
            :this()
        {
            this.razonSocial = nombreEmpresa;
        }

        #endregion

        #region Propiedades

        public float GananciasPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }

        public float GananciasPorProvincial
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }

        public float GananciasPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }

        #endregion

        #region Métodos

        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            foreach (Llamada L in this.listaDeLlamadas)
            {
                if (tipo == Llamada.TipoLlamada.Local || tipo == Llamada.TipoLlamada.Todas)
                {
 
                }
                else if (tipo == Llamada.TipoLlamada.Provincial || tipo == Llamada.TipoLlamada.Todas)
                {
 
                }
                
               
            }
            
            
            
            
            float output = 0;
            switch (tipo)
            {
                case Llamada.TipoLlamada.Local:
                    foreach (Llamada L in this.listaDeLlamadas)
                    {
                        if (L is Local) output += ((Local)L).CostoLlamada;
                    }
                    
                    break;
                case Llamada.TipoLlamada.Provincial:
                    foreach (Llamada L in this.listaDeLlamadas)
                    {
                        if (L is Provincial) output += ((Provincial)L).CostoLlamada;
                    }
                    break;
                default:
                    output = CalcularGanancia(Llamada.TipoLlamada.Local) + CalcularGanancia(Llamada.TipoLlamada.Provincial);
                    break;
            }
            return output;
        }

        private void AgregarLlamada (Llamada nuevaLlamada)
        {
            this.listaDeLlamadas.Add(nuevaLlamada);
        }

        public void OrdenarLlamadas()
        {
            this.listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }

        #endregion

        #region Redefinición de métodos

        public override string ToString()
        {
            StringBuilder sBuilder = new StringBuilder();
            sBuilder.AppendLine("Razón social: " + this.razonSocial);
            sBuilder.AppendFormat("Ganancia total: {0:F2}\n", this.GananciasPorTotal);
            sBuilder.AppendFormat("Ganancia llamadas locales: {0:F2}\n", this.GananciasPorLocal);
            sBuilder.AppendFormat("Ganancia llamadas provinciales: {0:F2}\n", this.GananciasPorProvincial);
            sBuilder.AppendLine("Detalle de las llamadas: ");

            foreach (Llamada L in this.listaDeLlamadas)
            {
                if (L is Local) sBuilder.Append(((Local)L).ToString());
                else if (L is Provincial) sBuilder.Append(((Provincial)L).ToString());
            }

            return sBuilder.ToString();
        }

        #endregion

        #region Sobrecarga de operadores
        public static bool operator ==(Centralita c, Llamada ll)
        {
            bool output = false;
            foreach (Llamada L in c.listaDeLlamadas)
            {
                if (L == ll) output = true;
            }
            return output;
        }

        public static bool operator !=(Centralita c, Llamada ll)
        {
            bool output = true;
            foreach (Llamada L in c.listaDeLlamadas)
            {
                if (L == ll) output = false;
            }
            return output;
        }

        public static Centralita operator +(Centralita c, Llamada nuevaLlamada)
        {
            if (c != nuevaLlamada) c.AgregarLlamada(nuevaLlamada);
            else if (c== nuevaLlamada)
            {
                throw new CentralitaException("La llamada ya se encuentra registrada", "Ae", "Japish");
            }
            return c;
        }

        #endregion
    }
}
