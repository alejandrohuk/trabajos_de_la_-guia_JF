﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralTelefonica
{
    public class Provincial : Llamada
    {
        protected Franja _franjaHoraria;

        #region Constructores

        public Provincial(string origen, Franja miFranja, float duracion, string destino)
            : base(duracion, destino, origen)
        {
            this._franjaHoraria = miFranja;
        }

        public Provincial(Franja miFranja, Llamada llamada)
            : this(llamada.NroOrigen, miFranja, llamada.Duracion, llamada.NroDestino)
        {
        }

        #endregion

        #region Propiedades

        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }

        private float CalcularCosto()
        {
            float output;
            switch (this._franjaHoraria)
            {
                case Franja.Franja_1:
                    output = this._duracion * 0.99F;
                    break;
                case Franja.Franja_2:
                    output = this._duracion * 1.25F;
                    break;
                default:
                    output = this._duracion * 0.66F;
                    break;
            }
            return output;
        }

        #endregion

        protected override string Mostrar()
        {
            StringBuilder sBuilder = new StringBuilder();
            sBuilder.Append(base.Mostrar());
            sBuilder.AppendLine("Costo de la llamada: " + this.CostoLlamada);
            sBuilder.AppendLine("Fraja horaria: " + _franjaHoraria);
            return sBuilder.ToString();
        }

        #region Redefinición de métodos

        public override bool Equals(Object obj)
        {
            bool output = false;
            if (obj is Provincial) output = true;
            return output;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        #endregion


        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
    }
}
