﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralTelefonica
{
    public class Local : Llamada
    {
        #region Campos
        
        protected float _costo;

        #endregion

        #region Constructores

        public Local(float duracion, string destino, string origen, float costo)
            :base(duracion, destino, origen)
        {
            this._costo = costo;
        }
        
        public Local(Llamada llamada, float costo)
            :this(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen, costo)
        {   
        }

        #endregion

        #region Propiedades

        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }

        #endregion

        #region Métodos

        private float CalcularCosto()
        {
            return this._costo * this._duracion;
        }

        protected override string Mostrar()
        {
            StringBuilder sBuilder = new StringBuilder();
            sBuilder.Append(base.Mostrar());
            sBuilder.AppendFormat("Costo de la llamada: {0:F2}\n", this.CostoLlamada);

            return sBuilder.ToString();
        }

        #endregion

        #region Redefinición de métodos

        public override bool Equals(Object obj)
        {
            bool output = false;
            if (obj is Local) output = true;
            return output;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        #endregion

    }
}
