﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_48
{
    public class Contabilidad<T, U>
    {
        private List<T> egresos;
        private List<U> ingresos;

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, T egreso)
        {
            return c;
        }

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, U ingreso)
        {
            return c;
        }

        private Contabilidad()
        {
            this.egresos = new List<T>();
            this.ingresos = new List<U>();
        }
    }
}